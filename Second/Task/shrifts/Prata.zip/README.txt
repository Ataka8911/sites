Prata is an elegant Didone typeface with sharp features and organic teardrops. There is a certain tension in the contrast of its virile serifs and soft refined curves. Its triangular serifs complement and accent the thin strokes, and the high contrast means it will work best in display sizes.

Designed by Ivan Petrov for Cyreal.